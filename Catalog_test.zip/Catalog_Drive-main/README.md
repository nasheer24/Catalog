1. Find the Source Code in Code.js file
2. Sample Test cases are defined in test1.json and test2.json
3. Output for both test cases are printed in code.js

<h1>Install Node js to execute JS in Localhost</h1>
<h3>To run use command</h3>
  node code.js
